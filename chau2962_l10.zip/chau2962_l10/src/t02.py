"""
-------------------------------------------------------
Lab 10, Task 02
-------------------------------------------------------
Author:  Tahir Chaudhry
ID:      169052962
Email:   chau2962@mylaurier.ca
__updated__ = "2024-03-24"
-------------------------------------------------------
"""
# Imports
from test_Sorts_array import test_sort
from Sorts_array import Sorts

# Constants


test_sort("Bubble Sort", Sorts.bubble_sort)
